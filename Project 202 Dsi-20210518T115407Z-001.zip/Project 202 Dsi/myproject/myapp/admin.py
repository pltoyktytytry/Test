from django.contrib import admin
from .models import Book, Buy, Collection, Customer, Favorite , Save

class CustomerAdmin(admin.ModelAdmin):
    list_display=['user','birth_date','gender','national','phone_num']
    list_editable=['phone_num']
admin.site.register(Customer,CustomerAdmin)

class BookAdmin(admin.ModelAdmin):
    list_display=[f.name for f in Book._meta.fields]
    list_editable=['price','detail']  
admin.site.register(Book,BookAdmin)

class BuyAdmin(admin.ModelAdmin):
    list_display=[f.name for f in Buy._meta.fields]
    list_editable=['amount','total_price']
admin.site.register(Buy,BuyAdmin)

class CollectionAdmin(admin.ModelAdmin):
    list_display=[f.name for f in Collection._meta.fields]
admin.site.register(Collection,CollectionAdmin)

class SaveAdmin(admin.ModelAdmin):
    list_display=[f.name for f in Save._meta.fields]
admin.site.register(Save,SaveAdmin)

class FavoriteAdmin(admin.ModelAdmin):
    list_display=[f.name for f in Favorite._meta.fields]
admin.site.register(Favorite,FavoriteAdmin)

