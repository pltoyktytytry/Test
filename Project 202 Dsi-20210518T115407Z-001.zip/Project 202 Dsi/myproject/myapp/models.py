from django.db import models
from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.utils.html import mark_safe
# Create your models here.
class Customer(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    phone_num=models.CharField(max_length=10)
    birth_date=models.DateTimeField()
    national=models.CharField(max_length=50)
    gender=models.CharField(max_length=10)
    def __str__(self):
        return ("%s %s  %s <national> : %s  %s"%(self.id ,self.user.first_name, self.user.last_name, self.national,self.gender))
    
class Book(models.Model):
    book_name=models.CharField(max_length=100)
    type=models.CharField(max_length=50)
    detail = models.TextField(null=True)
    author = models.CharField(max_length=50)
    publisher = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10,decimal_places=2)
    def __str__(self):
        return ("%s <type> : %s <price> : %s "%(self.book_name, self.type, self.price))

class Buy(models.Model):
    customer=models.ForeignKey(Customer, on_delete=models.CASCADE, null=True)
    book=models.ForeignKey(Book, on_delete=models.CASCADE,null=True)
    date=models.DateTimeField()
    amount=models.DecimalField(max_digits=5,decimal_places=0)
    total_price=models.DecimalField(max_digits=10,decimal_places=2)
    def __str__(self):
        return ("customer:%s  buy book:%s amount:%s total:%s "%(self.customer, self.book, self.amount,self.total_price))
class Collection(models.Model):
    customer=models.ForeignKey(Customer, on_delete=models.CASCADE, null=True)
    book=models.ForeignKey(Book, on_delete=models.CASCADE,null=True)
    def __str__(self):
        return ("customer:%s one of collection is :%s"%(self.customer, self.book))
class Save(models.Model):
    customer=models.ForeignKey(Customer, on_delete=models.CASCADE, null=True)
    book=models.ForeignKey(Book, on_delete=models.CASCADE,null=True)
    def __str__(self):
        return ("customer:%s save %s"%(self.customer, self.book))
class Favorite(models.Model):
    customer=models.ForeignKey(Customer, on_delete=models.CASCADE, null=True)
    book=models.ForeignKey(Book, on_delete=models.CASCADE,null=True)
    def __str__(self):
        return ("customer:%s one of favorite book is :%s"%(self.customer, self.book))