from django.shortcuts import render,redirect
from django.http import HttpResponse
import datetime
from .models import Customer,Book,Buy
from django.views.generic.list import ListView
from django.contrib.auth.models import User,auth
from django.contrib import messages
from datetime import datetime


# Create your views here.
def home(request):
    return render(request,'home2.html')
def update(request):
    return render(request,'update.html')
def favorite(request):
    return render(request,'favorite.html')
def dowload(request):
    return render(request,'dowload.html')
def user(request):
    return render(request,'user.html')
def bookstore(request):
    return render(request,'book-store.html')  
def user_mybook(request):
    return render(request,'user-mybook.html')
def user_collection(request):
    return render(request,'user-collection.html')
def book_cart(request):
    return render(request,'book_cart.html')
def book_detail(request):
    return render(request,'book-detail.html')
def book_store_collection(request):
    return render(request,'book-store-collection.html')
def book_paid_success(request):
    return render(request,'book_paid_success.html')
def book_paid(request):
    return render(request,'book_paid.html')
def cate(request):
    return render(request,'cate.html')
def following(request):
    return render(request,'following.html')
def loginForm(request):
    return render(request,'index.html')
def sign_up(request):
    return render(request,'regis.html')
def success(request):
    return render(request,'success.html')
def addUser(request):
    username=request.POST.get('username',False)
    firstname=request.POST.get('firstname',False)
    lastname=request.POST.get('lastname',False)
    email=request.POST['email']
    password=request.POST['password']
    repassword=request.POST['repassword']
    date=request.POST.get('date',False)
    phone_num=request.POST['phone_num']
    national=request.POST['national']
    gender=request.POST.get('gender',False)
    if password==repassword:
        if User.objects.filter(username=username).exists():
            messages.info(request,"This User id has already been registered.")
            return redirect('/sign_up')
        if  email=='' or date=='':
            messages.info(request,"Please fill all data")
            return redirect('/sign_up')
        elif  User.objects.filter(email=email).exists():
            messages.info(request,"This email has already been registered.")
            return redirect('/sign_up')

        else:
            new_user= User.objects.create_user(
            username=username,
            password=password,
            email=email,            
            first_name=firstname,
            last_name=lastname
            )
            customer=Customer.objects.create(
            user=new_user,
            phone_num=phone_num,
            birth_date=date,
            national=national,
            gender=gender
            )
            new_user.save()
            customer.save()
            return redirect('/cate')
    else:
        messages.info(request,"password doesn't match")
        return redirect('/sign_up')
def login(request):
    username=request.POST['username']
    password=request.POST['password']
     #login
    user=auth.authenticate(username=username,password=password)
    if user is not None:
        auth.login(request,user)
        return redirect('/home')
    else:
        messages.info(request,"Data not found please Try again")
        return redirect('/')
def buy_harry(request):
    user = User.objects.get(username=request.user.username)
    current_date=datetime.now()
    book = Book.objects.get(book_name='Harry')
    amount = request.POST['amount']
    total_price = int(amount)*19.2
    Buy.objects.create(
        customer = Customer.objects.get(user=user),
        book = book,
        date = current_date,
        amount = amount,
        total_price = total_price
    )
    return redirect('/book_paid')

def logout(request):
    auth.logout(request)
    return redirect('/')
def fav(request):
    return redirect('/')
def please(request):
    return redirect('/')

def book_example(request):
    return render(request,'book_example.html')